* Jolicraft, my first source of inspiration !
http://www.jolicraft.com/

* LB Photo Realisme, for the damage animation !
http://www.minecraftforum.net/viewtopic.php?t=136785

* Notch ! for the beautiful dark blue water & the ultra red lava ! =D
http://www.minecraft.net

* Milktache, for setting up SummerFields on the customizer !

* Marcinz606, for the lightmap and all the custom colors, sky, and all.. =)

* Sixdd, for the ctm.png file.

* CuddleWoozle, for the alternate cow & sheep.

*Lipki, for making the horse armor, markings and horses!  (And initially converting the texture pack to a resource pack.)

*SilverLimit for the new quartz block textures!

		----------------


If you play with some mod, you should download mod support for summerfields :
- On the summerfields thread you can download all of them.

* Tale of kingdoms support :
	http://adf.ly/4AC20

* Claysoldiers support :
	http://adf.ly/4EurC

* Wurstknifte's bookmod support :
	http://adf.ly/4ABx8

* Better Than Wolves support :
	NO LINK YET !
	Comming December 31 2011 ! 
	Check Summerfields thread if the date is passed !
    
		----------------
        
I, CuddleWoozle, have updated SummerFields to be compatible with the 1.5 Minecraft release.  I have also filled in a lot of missing textures.

I take absolutely no credit for Lithium's original work.  I am only updating this pack while he is gone so that people can continue to enjoy SummerFields.

		----------------

5/7/2013 :
Fixed file structure so the .zip is recognized by Minecraft.
Updated this thread and added more mod support!
Changed the Hay Bale slightly.

13/3/2013 :

List of CuddleWoozle created textures

(using Lithium's work as a base)

Activator Rails (Powered and non-powered)
Anvil textures
Comparator (lit and unlit)
Daylight Detector
Dropper
Hopper
Nether Quartz
Comparator item
Clock item (1.5 update)
Compass item (1.5 update)
Minecart with hopper and TNT
Nether brick item
Black Bat Mob
Ender Crystal
Beacon
Underwater overlay
Trapped chests
Repair GUI

Original Works

Quartz blocks (bottom, chisled, chisled top, lines, line top, sides and top)
Firework item
Firework charge and overlay
Hopper item
Nether quartz item
Saddle
Ender Crystal Beam
Beacon beam

14/09/12 :
Updated leather armor +icon
Pumpkin pie icon
Updated zombie skin
Updated pigman
Added zombie vilagger

22/03/12 :
For minecraft 1.2.4 & all pre-release !
Added new plank for redwood birch and jungle tree, new sandstone.

08/03/12 :
Added many many new alternate mobs !
(creeper, cow, squid, slime, zombie...)

03/02/12 :
Added ozelot, red cat, black cat, siamese cat & jungle tree sapling

20/01/12 :
New jungle leaves, new jungle wood log

14/01/12 :
Fixed lightmap, New GUI, fixed GUI(language button)
Torch now blink a little less, cave are a little less dark

14/01/12 :
Dragon skin, villagers, spwaning eggs, lightmap, custom colors, kz 100% done...

31/12/11 :
New dyes, better cauldron, fixed painting

28/11/11 :
New animated water, new animated lava, some fix on the GUI (hunger, healt)

19/11/11 :
New GUI : reticul, healt, hardcore healt, hungry, XP barre, dragon life...

12/11/11 :
All mobs, Many new painting, fixed GUI, alt mobs...

29/10/11 :
All the GUI is now finished ! New moon, new sun...

07/10/11 :
All 1.9.3 items & blocks, 3 new mobs : Skeleton, spider & cave spider !

30/09/11 :
All 1.9.2 items & blocks, all disk, slime & ghast !

26/09/11 :
Many textures change, 1.9 items & blocks, xp orbs, new chest, Enderman !

11/09/11 :
Added Chiken, zombie, cow and all 1.8 items/block

28/08/11 :
All armor finished !

23/07/11 :
Tools and weapons finished, most of objects finished,leather armor, Char.png file (...in underpants =D).

10/07/11 :
Terrain.png slightly modified, Item folder Finished, Items.png Almost finished,Alternate version for the sign...

29/06/11 :
New redwood leaves, New glowstone block, futur piston texture...


