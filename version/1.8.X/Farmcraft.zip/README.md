Modification du pack SummerfieldsCraft de LithiumSound  
http://www.minecraftforum.net/topic/1715841-summerfields-new-mod-support-bibliocraft-backpacks-and-multipage-chest/

Vers l'infini et au-delà !

lipki
