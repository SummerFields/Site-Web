SummerFields
============

This is the add-on 3d model for Summerfields 1.8
To use, add to Summerfields pack 1.8 in the list of "ressources pack"

Created by Lipki 

SummerFields, is started by LithiumSound and now continued by  CuddleWoozle.
