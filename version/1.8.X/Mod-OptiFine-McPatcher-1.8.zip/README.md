﻿[![SummerFields] (http://summerfields.github.io/official/signature/sign2.png) ] (http://summerfields.github.io/official/)
============

This is the add-on 3d model for Summerfields 1.8
To use, add to Summerfields pack 1.8 in the list of "ressources pack"

Created by comunity

History of Recent Updates
-------------------------

12/09/2014 : Release 1.8 bêta
* Added
  - new mob textures for MCPatcher by [lipki] (https://github.com/lipki)

4/08/2014 : Release 1.7.10
* Changes
  - mcpatcher correct by [2LEPRECHAUN] (https://github.com/2LEPRECHAUN)
