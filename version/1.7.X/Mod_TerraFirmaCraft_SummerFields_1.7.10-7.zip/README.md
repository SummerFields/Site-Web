Mod TerraFirmaCraft for SummerFields 1.7.10
===========================================

This is the support mod "TerraFirmaCraft" for Summerfields 1.7.10
To use, add to Summerfields pack 1.7.x in the list of "ressources pack"

Created by Summerfields Team

SummerFields, is started by LithiumSound and now continued by CuddleWoozle.

20/09/2014
----------

- Completed by the "Faithfull for TerraFirmaCraft" for non-custom textures
- ingot color by sandromonti
- everything else by Lipki
