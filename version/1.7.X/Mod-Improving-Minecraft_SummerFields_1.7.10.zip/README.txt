Mod Improving Minecraft for SummerFields
==========================

Minecraft 1.7.10

This is the support mod "Improving Minecraft" for Summerfields
To use, add to Summerfields pack in the list of "ressources pack"

Created by Summerfields Team
SummerFields, is started by LithiumSound.
http://summerfields.github.io/official

Improving Minecraft, is started by pifou92000
http://forum.minecraft-france.fr/threads/improving-minecraft.19915/