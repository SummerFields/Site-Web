﻿[![SummerFields] (http://summerfields.github.io/official/signature/sign2.png) ] (http://summerfields.github.io/official/)

Custom Pack

Notes 
-----
        
* LithiumSound has created SummerFields. 
* CuddleWoozle continued the texture pack. 
* Currently external contributions are helping the package to stay updated.

Thanks
------

* [Jolicraft] (http://www.jolicraft.com/) - My first source of inspiration!
* [LB Photo Realisme] (http://www.minecraftforum.net/forums/mapping-and-modding/resource-packs/1223855-lb-photo-realism-1-6-convert-7-16-2013-rpg-realism) - For the damage animation!
* [Notch] (http://www.minecraft.net) - For the beautiful dark blue water & the ultra red lava! =D


* [tobyplowy] (https://github.com/tobyplowy) - For this custom pack